class Currency < ApplicationRecord
  has_many :accounts
end
