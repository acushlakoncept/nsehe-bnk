class Transaction < ApplicationRecord
   belongs_to :user
end
