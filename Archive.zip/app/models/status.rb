class Status < ApplicationRecord
  has_many :accounts
end
