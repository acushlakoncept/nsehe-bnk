class AccountType < ApplicationRecord
  has_many :accounts
end
